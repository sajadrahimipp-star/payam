(() => {
  const $ = id => document.getElementById(id);
  const state = {
    mode: "login",
    me: null,
    chats: [],
    contacts: [],
    activeChatId: null,
    messages: [],
    socket: null,
    sideTab: "chats",
    typingTimer: null
  };
  const palette = ["#2AABEE", "#7667e8", "#d17ab1", "#36a99d", "#db9458", "#5f91cf", "#a078cb"];
  let toastTimer;
  let typingTimeout;

  async function api(url, options = {}) {
    const response = await fetch(url, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "درخواست انجام نشد.");
    return data;
  }

  function toast(message) {
    $("toast").textContent = message;
    $("toast").classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2800);
  }

  function avatarColor(id) {
    return palette[(id || 0) % palette.length];
  }

  function formatTime(iso) {
    if (!iso) return "";
    const d = new Date(iso.replace(" ", "T") + (iso.includes("Z") ? "" : "Z"));
    if (Number.isNaN(d.getTime())) return "";
    const now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    if (sameDay) return d.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
    return d.toLocaleDateString("fa-IR", { month: "short", day: "numeric" });
  }

  function typeLabel(type) {
    if (type === "group") return "گروه";
    if (type === "channel") return "کانال";
    return "";
  }

  // ---------- Auth ----------
  function setMode(mode) {
    state.mode = mode;
    $("loginTab").classList.toggle("active", mode === "login");
    $("registerTab").classList.toggle("active", mode === "register");
    $("displayNameLabel").classList.toggle("hidden", mode !== "register");
    $("authSubmit").textContent = mode === "login" ? "ورود به نووا" : "ساخت حساب";
    $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
    $("authNotice").textContent = "";
  }

  $("loginTab").addEventListener("click", () => setMode("login"));
  $("registerTab").addEventListener("click", () => setMode("register"));

  $("authForm").addEventListener("submit", async event => {
    event.preventDefault();
    $("authSubmit").disabled = true;
    $("authNotice").textContent = "";
    const payload = {
      username: $("username").value.trim(),
      password: $("password").value,
      displayName: $("displayName").value.trim()
    };
    try {
      const result = await api(`/api/${state.mode}`, { method: "POST", body: JSON.stringify(payload) });
      await enterApp(result.user);
    } catch (error) {
      $("authNotice").textContent = error.message;
    } finally {
      $("authSubmit").disabled = false;
    }
  });

  async function enterApp(user) {
    state.me = user;
    $("authView").classList.add("hidden");
    $("appView").classList.remove("hidden");
    $("myName").textContent = user.displayName;
    $("myHandle").textContent = "@" + user.username;
    $("myAvatar").textContent = user.displayName.slice(0, 1);
    $("myAvatar").style.background = `linear-gradient(135deg,${avatarColor(user.id)},#39b6c2)`;
    document.body.classList.add("dark");
    await Promise.all([loadChats(), loadContacts()]);
    connectSocket();
  }

  // ---------- Lists ----------
  async function loadChats() {
    const result = await api("/api/chats");
    state.chats = result.chats || [];
    renderChatList();
  }

  async function loadContacts() {
    const result = await api("/api/contacts");
    state.contacts = result.contacts || [];
    renderContactList();
  }

  function renderChatList() {
    const query = $("searchInput").value.trim().toLocaleLowerCase("fa");
    const filtered = state.chats.filter(c =>
      (c.title || "").toLocaleLowerCase("fa").includes(query) ||
      (c.peer && (c.peer.displayName.toLocaleLowerCase("fa").includes(query) || c.peer.username.includes(query)))
    );
    const list = $("chatList");
    list.replaceChildren();

    if (!filtered.length) {
      const empty = document.createElement("div");
      empty.className = "empty-list";
      empty.textContent = state.chats.length
        ? "گفتگویی پیدا نشد."
        : "هنوز گفتگویی نداری. با دکمه ＋ شروع کن.";
      list.append(empty);
      return;
    }

    filtered.forEach(chat => {
      const item = document.createElement("div");
      item.className = "chat-item" + (chat.id === state.activeChatId ? " active" : "");
      item.addEventListener("click", () => openChat(chat.id));

      const av = document.createElement("div");
      av.className = "avatar" + (chat.peer && chat.peer.online ? " online" : "");
      av.style.background = `linear-gradient(135deg,${avatarColor(chat.peer ? chat.peer.id : chat.id)},#39b6c2)`;
      av.textContent = (chat.title || "?").slice(0, 1);

      const meta = document.createElement("div");
      meta.className = "chat-meta";

      const top = document.createElement("div");
      top.className = "top";
      const name = document.createElement("strong");
      name.textContent = chat.title;
      if (chat.type !== "private") {
        const badge = document.createElement("span");
        badge.className = "type-badge";
        badge.textContent = typeLabel(chat.type);
        name.append(badge);
      }
      const time = document.createElement("span");
      time.className = "time";
      time.textContent = chat.lastMessage ? formatTime(chat.lastMessage.createdAt) : "";
      top.append(name, time);

      const bottom = document.createElement("div");
      bottom.className = "bottom";
      const preview = document.createElement("span");
      preview.className = "preview";
      if (chat.lastMessage) {
        const prefix = chat.type !== "private" && chat.lastMessage.senderId !== state.me.id
          ? chat.lastMessage.senderName + ": "
          : (chat.lastMessage.senderId === state.me.id ? "شما: " : "");
        preview.textContent = prefix + chat.lastMessage.body;
      } else {
        preview.textContent = chat.type === "channel" ? "کانال جدید" : "هنوز پیامی نیست";
      }
      bottom.append(preview);
      if (chat.unread > 0) {
        const badge = document.createElement("span");
        badge.className = "badge";
        badge.textContent = chat.unread > 99 ? "99+" : String(chat.unread);
        bottom.append(badge);
      }

      meta.append(top, bottom);
      item.append(av, meta);
      list.append(item);
    });
  }

  function renderContactList() {
    const query = $("searchInput").value.trim().toLocaleLowerCase("fa");
    const filtered = state.contacts.filter(c =>
      c.displayName.toLocaleLowerCase("fa").includes(query) ||
      c.username.toLowerCase().includes(query)
    );
    const list = $("contactList");
    list.replaceChildren();

    if (!filtered.length) {
      const empty = document.createElement("div");
      empty.className = "empty-list";
      empty.textContent = state.contacts.length
        ? "مخاطبی پیدا نشد."
        : "هنوز مخاطبی نداری. از جستجو کاربر اضافه کن.";
      list.append(empty);
      return;
    }

    filtered.forEach(user => {
      const item = document.createElement("div");
      item.className = "contact-item";
      item.addEventListener("click", () => startPrivateChat(user.id));

      const av = document.createElement("div");
      av.className = "avatar" + (user.online ? " online" : "");
      av.style.background = `linear-gradient(135deg,${avatarColor(user.id)},#39b6c2)`;
      av.textContent = user.displayName.slice(0, 1);

      const meta = document.createElement("div");
      meta.className = "chat-meta";
      const top = document.createElement("div");
      top.className = "top";
      const name = document.createElement("strong");
      name.textContent = user.displayName;
      top.append(name);
      const bottom = document.createElement("div");
      bottom.className = "bottom";
      const preview = document.createElement("span");
      preview.className = "preview";
      preview.textContent = "@" + user.username + (user.online ? " · آنلاین" : "");
      bottom.append(preview);
      meta.append(top, bottom);
      item.append(av, meta);
      list.append(item);
    });
  }

  // Side tabs
  document.querySelectorAll(".side-tab").forEach(btn => {
    btn.addEventListener("click", () => {
      state.sideTab = btn.dataset.tab;
      document.querySelectorAll(".side-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === state.sideTab));
      $("chatList").classList.toggle("hidden", state.sideTab !== "chats");
      $("contactList").classList.toggle("hidden", state.sideTab !== "contacts");
      $("searchInput").placeholder = state.sideTab === "chats" ? "جستجوی گفتگو..." : "جستجوی مخاطب...";
      if (state.sideTab === "chats") renderChatList();
      else renderContactList();
    });
  });

  $("searchInput").addEventListener("input", () => {
    if (state.sideTab === "chats") renderChatList();
    else renderContactList();
  });

  // ---------- Open chat ----------
  async function openChat(chatId) {
    state.activeChatId = chatId;
    renderChatList();
    $("appView").classList.add("chat-open");

    const chat = state.chats.find(c => c.id === chatId);
    if (!chat) {
      await loadChats();
      return openChat(chatId);
    }

    // Header
    const info = $("chatHeaderInfo");
    info.replaceChildren();
    const av = document.createElement("div");
    av.className = "avatar" + (chat.peer && chat.peer.online ? " online" : "");
    av.style.background = `linear-gradient(135deg,${avatarColor(chat.peer ? chat.peer.id : chat.id)},#39b6c2)`;
    av.textContent = (chat.title || "?").slice(0, 1);
    const text = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = chat.title;
    const status = document.createElement("span");
    if (chat.type === "private" && chat.peer) {
      status.textContent = chat.peer.online ? "● آنلاین" : "● آفلاین";
      status.style.color = chat.peer.online ? "var(--online)" : "";
    } else if (chat.type === "group") {
      status.textContent = chat.memberCount + " عضو";
    } else {
      status.textContent = chat.memberCount + " مشترک · کانال";
    }
    text.append(name, status);
    info.append(av, text);
    $("chatInfoBtn").style.visibility = "visible";

    $("messageForm").classList.remove("hidden");
    const canWrite = chat.type !== "channel" || chat.role === "owner" || chat.role === "admin";
    $("messageInput").disabled = !canWrite;
    $("messageInput").placeholder = canWrite ? "پیامت رو بنویس..." : "فقط ادمین‌ها می‌توانند در کانال بنویسند";
    $("messageInput").focus();

    $("chatContent").innerHTML = '<div class="date-divider"><span>در حال بارگذاری...</span></div>';
    try {
      const result = await api(`/api/chats/${chatId}/messages`);
      if (state.activeChatId !== chatId) return;
      state.messages = result.messages || [];
      renderMessages();
      // Clear unread locally
      chat.unread = 0;
      renderChatList();
      if (state.socket) state.socket.emit("join_chat", chatId);
    } catch (error) {
      toast(error.message);
    }
  }

  function renderMessages() {
    const container = $("chatContent");
    container.replaceChildren();
    if (!state.messages.length) {
      const empty = document.createElement("div");
      empty.className = "welcome";
      const title = document.createElement("h2");
      title.textContent = "هنوز پیامی نیست";
      const desc = document.createElement("p");
      desc.textContent = "اولین پیام را بفرست!";
      empty.append(title, desc);
      container.append(empty);
      return;
    }

    let lastDate = "";
    state.messages.forEach(msg => {
      const d = new Date((msg.createdAt || "").replace(" ", "T") + "Z");
      const dateStr = Number.isNaN(d.getTime()) ? "" : d.toLocaleDateString("fa-IR", { year: "numeric", month: "long", day: "numeric" });
      if (dateStr && dateStr !== lastDate) {
        lastDate = dateStr;
        const div = document.createElement("div");
        div.className = "date-divider";
        const span = document.createElement("span");
        span.textContent = dateStr;
        div.append(span);
        container.append(div);
      }

      const mine = msg.senderId === state.me.id;
      const row = document.createElement("div");
      row.className = "message-row " + (mine ? "mine" : "theirs");
      const bubble = document.createElement("div");
      bubble.className = "bubble";

      const chat = state.chats.find(c => c.id === state.activeChatId);
      if (!mine && chat && chat.type !== "private") {
        const sender = document.createElement("div");
        sender.className = "sender-name";
        sender.textContent = msg.senderName || "کاربر";
        bubble.append(sender);
      }

      const body = document.createElement("div");
      body.className = "body";
      body.textContent = msg.body;
      const meta = document.createElement("div");
      meta.className = "msg-meta";
      meta.textContent = formatTime(msg.createdAt);
      bubble.append(body, meta);
      row.append(bubble);
      container.append(row);
    });
    container.scrollTop = container.scrollHeight;
  }

  // ---------- Private / Group / Channel ----------
  async function startPrivateChat(userId) {
    try {
      const result = await api("/api/chats/private", {
        method: "POST",
        body: JSON.stringify({ userId })
      });
      await loadChats();
      await loadContacts();
      closeModal();
      openChat(result.chat.id);
    } catch (e) {
      toast(e.message);
    }
  }

  function showActionSheet() {
    $("actionSheetOverlay").classList.remove("hidden");
  }
  function hideActionSheet() {
    $("actionSheetOverlay").classList.add("hidden");
  }

  $("fabBtn").addEventListener("click", showActionSheet);
  $("actionSheetOverlay").addEventListener("click", e => {
    if (e.target === $("actionSheetOverlay")) hideActionSheet();
  });
  $("actionSheet").addEventListener("click", e => {
    const btn = e.target.closest("button");
    if (!btn) return;
    const action = btn.dataset.action;
    hideActionSheet();
    if (action === "private") openNewPrivateModal();
    else if (action === "group") openCreateGroupModal();
    else if (action === "channel") openCreateChannelModal();
  });

  // Modal helpers
  function openModal(title, bodyHtml) {
    $("modalTitle").textContent = title;
    $("modalBody").innerHTML = bodyHtml;
    $("modalOverlay").classList.remove("hidden");
  }
  function closeModal() {
    $("modalOverlay").classList.add("hidden");
    $("modalBody").innerHTML = "";
  }
  $("modalClose").addEventListener("click", closeModal);
  $("modalOverlay").addEventListener("click", e => {
    if (e.target === $("modalOverlay")) closeModal();
  });

  function openNewPrivateModal() {
    openModal("چت شخصی جدید", `
      <div class="form-group">
        <label>جستجوی کاربر</label>
        <input id="userSearchInput" placeholder="نام کاربری یا نام نمایشی..." autocomplete="off">
      </div>
      <div class="search-results" id="userSearchResults"></div>
    `);
    const input = $("userSearchInput");
    let timer;
    input.addEventListener("input", () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const q = input.value.trim();
        if (q.length < 1) {
          $("userSearchResults").innerHTML = "";
          return;
        }
        try {
          const result = await api("/api/users/search?q=" + encodeURIComponent(q));
          const box = $("userSearchResults");
          box.replaceChildren();
          if (!result.users.length) {
            box.innerHTML = '<div class="empty-list">کاربری پیدا نشد</div>';
            return;
          }
          result.users.forEach(u => {
            const row = document.createElement("div");
            row.className = "search-result-item";
            row.innerHTML = `
              <div class="avatar" style="background:linear-gradient(135deg,${avatarColor(u.id)},#39b6c2)">${u.displayName.slice(0,1)}</div>
              <div><strong>${escapeHtml(u.displayName)}</strong><br><span style="font-size:12px;color:var(--text-secondary)">@${escapeHtml(u.username)}${u.isContact ? " · مخاطب" : ""}</span></div>
            `;
            row.addEventListener("click", () => startPrivateChat(u.id));
            box.append(row);
          });
        } catch (e) {
          toast(e.message);
        }
      }, 250);
    });
    input.focus();
  }

  function openCreateGroupModal() {
    openModal("ساخت گروه", `
      <div class="form-group">
        <label>عنوان گروه</label>
        <input id="groupTitle" maxlength="60" placeholder="مثلاً دوستان دانشگاه">
      </div>
      <div class="form-group">
        <label>اعضا (از مخاطبین)</label>
        <div class="member-pick" id="groupMembers"></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-secondary" id="cancelGroup">انصراف</button>
        <button type="button" class="btn-primary" id="createGroupBtn">ساخت گروه</button>
      </div>
    `);
    const pick = $("groupMembers");
    if (!state.contacts.length) {
      pick.innerHTML = '<div class="empty-list">ابتدا چند مخاطب اضافه کن</div>';
    } else {
      state.contacts.forEach(c => {
        const label = document.createElement("label");
        label.innerHTML = `<input type="checkbox" value="${c.id}"> ${escapeHtml(c.displayName)} <span style="color:var(--text-muted);font-size:12px">@${escapeHtml(c.username)}</span>`;
        pick.append(label);
      });
    }
    $("cancelGroup").addEventListener("click", closeModal);
    $("createGroupBtn").addEventListener("click", async () => {
      const title = $("groupTitle").value.trim();
      const memberIds = [...pick.querySelectorAll("input:checked")].map(i => Number(i.value));
      if (title.length < 2) return toast("عنوان گروه را وارد کن");
      try {
        const result = await api("/api/chats/group", {
          method: "POST",
          body: JSON.stringify({ title, memberIds })
        });
        await loadChats();
        closeModal();
        openChat(result.chat.id);
        toast("گروه ساخته شد");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function openCreateChannelModal() {
    openModal("ساخت کانال", `
      <div class="form-group">
        <label>عنوان کانال</label>
        <input id="channelTitle" maxlength="60" placeholder="مثلاً اخبار فناوری">
      </div>
      <div class="form-group">
        <label>توضیحات (اختیاری)</label>
        <textarea id="channelDesc" maxlength="300" placeholder="درباره کانال..."></textarea>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-secondary" id="cancelChannel">انصراف</button>
        <button type="button" class="btn-primary" id="createChannelBtn">ساخت کانال</button>
      </div>
    `);
    $("cancelChannel").addEventListener("click", closeModal);
    $("createChannelBtn").addEventListener("click", async () => {
      const title = $("channelTitle").value.trim();
      const description = $("channelDesc").value.trim();
      if (title.length < 2) return toast("عنوان کانال را وارد کن");
      try {
        const result = await api("/api/chats/channel", {
          method: "POST",
          body: JSON.stringify({ title, description })
        });
        await loadChats();
        closeModal();
        openChat(result.chat.id);
        toast("کانال ساخته شد");
      } catch (e) {
        toast(e.message);
      }
    });
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // Chat info modal
  $("chatInfoBtn").addEventListener("click", async () => {
    if (!state.activeChatId) return;
    try {
      const result = await api(`/api/chats/${state.activeChatId}`);
      const chat = result.chat;
      const members = result.members || [];
      let html = `
        <div style="text-align:center;margin-bottom:16px">
          <div class="avatar" style="width:64px;height:64px;font-size:24px;margin:0 auto 8px;background:linear-gradient(135deg,${avatarColor(chat.id)},#39b6c2)">${(chat.title||"?").slice(0,1)}</div>
          <strong style="font-size:16px">${escapeHtml(chat.title)}</strong>
          <div style="font-size:13px;color:var(--text-secondary);margin-top:4px">${typeLabel(chat.type) || "چت شخصی"} · ${chat.memberCount} نفر</div>
          ${chat.description ? `<p style="font-size:13px;margin-top:8px;color:var(--text-secondary)">${escapeHtml(chat.description)}</p>` : ""}
        </div>
        <div style="font-size:13px;color:var(--text-muted);margin-bottom:8px">اعضا</div>
        <div class="member-pick">
      `;
      members.forEach(m => {
        const role = m.role === "owner" ? " (سازنده)" : m.role === "admin" ? " (ادمین)" : "";
        html += `<div style="padding:8px 12px;display:flex;align-items:center;gap:10px">
          <div class="avatar" style="width:32px;height:32px;font-size:13px;background:linear-gradient(135deg,${avatarColor(m.id)},#39b6c2)">${m.displayName.slice(0,1)}</div>
          <div><strong>${escapeHtml(m.displayName)}</strong>${role}<br><span style="font-size:12px;color:var(--text-secondary)">@${escapeHtml(m.username)}</span></div>
        </div>`;
      });
      html += "</div>";
      openModal("اطلاعات گفتگو", html);
    } catch (e) {
      toast(e.message);
    }
  });

  // ---------- Socket ----------
  function connectSocket() {
    if (state.socket) state.socket.disconnect();
    state.socket = io();
    state.socket.on("connect_error", () => toast("اتصال زنده برقرار نشد؛ صفحه را تازه‌سازی کن."));

    state.socket.on("presence", event => {
      // Update contacts
      const contact = state.contacts.find(c => c.id === event.userId);
      if (contact) contact.online = event.online;
      // Update peer in chats
      state.chats.forEach(c => {
        if (c.peer && c.peer.id === event.userId) c.peer.online = event.online;
      });
      if (state.sideTab === "chats") renderChatList();
      else renderContactList();
      if (state.activeChatId) {
        const chat = state.chats.find(c => c.id === state.activeChatId);
        if (chat && chat.peer && chat.peer.id === event.userId) {
          const statusEl = $("chatHeaderInfo").querySelector("span");
          if (statusEl) {
            statusEl.textContent = event.online ? "● آنلاین" : "● آفلاین";
            statusEl.style.color = event.online ? "var(--online)" : "";
          }
        }
      }
    });

    state.socket.on("new_message", message => {
      // Update chat list
      const chat = state.chats.find(c => c.id === message.chatId);
      if (chat) {
        chat.lastMessage = {
          id: message.id,
          body: message.body,
          createdAt: message.createdAt,
          senderId: message.senderId,
          senderName: message.senderName
        };
        if (message.chatId !== state.activeChatId && message.senderId !== state.me.id) {
          chat.unread = (chat.unread || 0) + 1;
        }
        // Move to top
        state.chats = [chat, ...state.chats.filter(c => c.id !== chat.id)];
        renderChatList();
      } else {
        loadChats().catch(() => {});
      }

      if (message.chatId === state.activeChatId) {
        if (!state.messages.some(m => m.id === message.id)) {
          state.messages.push(message);
          renderMessages();
        }
      } else if (message.senderId !== state.me.id) {
        toast("پیام جدید: " + (message.body.slice(0, 40) + (message.body.length > 40 ? "…" : "")));
      }
    });

    state.socket.on("typing", event => {
      if (event.chatId !== state.activeChatId || event.userId === state.me.id) return;
      $("typingBar").textContent = (event.displayName || "کسی") + " در حال نوشتن است…";
      $("typingBar").classList.remove("hidden");
      clearTimeout(state.typingTimer);
      state.typingTimer = setTimeout(() => $("typingBar").classList.add("hidden"), 2500);
    });

    state.socket.on("chat_error", event => toast(event.error));
  }

  // Composer
  $("messageForm").addEventListener("submit", event => {
    event.preventDefault();
    const body = $("messageInput").value.trim();
    if (!body || !state.activeChatId || !state.socket?.connected) {
      if (body && !state.socket?.connected) toast("اتصال برقرار نیست.");
      return;
    }
    state.socket.emit("send_message", { chatId: state.activeChatId, body });
    $("messageInput").value = "";
  });

  $("messageInput").addEventListener("input", () => {
    if (!state.activeChatId || !state.socket?.connected) return;
    clearTimeout(typingTimeout);
    state.socket.emit("typing", { chatId: state.activeChatId });
    typingTimeout = setTimeout(() => {}, 1000);
  });

  // Navigation
  $("backBtn").addEventListener("click", () => {
    state.activeChatId = null;
    $("appView").classList.remove("chat-open");
    $("messageForm").classList.add("hidden");
    $("chatInfoBtn").style.visibility = "hidden";
    $("chatHeaderInfo").innerHTML = `
      <div class="empty-avatar">✦</div>
      <div><strong>به نووا خوش اومدی</strong><span>یک گفتگو انتخاب کن یا بساز</span></div>
    `;
    $("chatContent").innerHTML = `
      <div class="welcome">
        <div class="welcome-icon">✦</div>
        <h2>گفتگوی خوب از اینجا شروع می‌شه</h2>
        <p>از فهرست کنار صفحه یک گفتگو انتخاب کن، یا با دکمه ＋ گروه و کانال بساز.</p>
      </div>
    `;
    renderChatList();
  });

  $("logoutBtn").addEventListener("click", async () => {
    try { await api("/api/logout", { method: "POST", body: "{}" }); } catch (_) {}
    if (state.socket) state.socket.disconnect();
    location.reload();
  });

  $("themeBtn").addEventListener("click", () => {
    document.body.classList.toggle("dark");
  });

  $("menuBtn").addEventListener("click", () => {
    toast("نووا · نسخه ۲.۰ — شبیه تلگرام");
  });

  // Init
  api("/api/me").then(result => {
    if (result.user) enterApp(result.user).catch(error => toast(error.message));
  }).catch(() => {});
})();
